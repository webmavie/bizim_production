
<?php $__env->startSection('title', 'Xidmətlər'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <h1 class="m-0">Xidmətlər
                            <a href="<?php echo e(route('admin.service.create')); ?>" class="btn btn-success float-right">Yeni</a>
                        </h1>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 20px">#</th>
                                <th>Şəkil</th>
                                <th>Ad</th>
                                <th>Əsas Açıqlama</th>
                                <th>Prc</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="#" class="align-middle"><?php echo e($service->id); ?></td>
                                    <td data-label="Şəkil" style="width: 200px" class="align-middle">
                                        <a target="_blank" href="<?php echo e(asset($service->main_image)); ?>">
                                            <img class="table_img" style="width: 100%; height: auto" src="<?php echo e(asset($service->main_image)); ?>"
                                                alt="<?php echo e($service->name); ?>">
                                        </a>
                                    </td>
                                    <td data-label="Ad" class="align-middle"><?php echo e($service->name); ?></td>
                                    <td class="desctd" data-label="Əsas Açıqlama" style="width: 500px; overflow: visible; height: auto;" class="align-middle"><?php echo e($service->main_description); ?></td>
                                    <td data-label="Prc" class="align-middle">
                                        <div class="prc"
                                            style="height: 100%; gap: 5px; display: grid; justify-content: center; align-services:center;">
                                            <?php if($service->images_exists): ?>
                                                <a class="btn btn-primary" title="Şəkillər"
                                                    href="<?php echo e(route('admin.service.images', $service->id)); ?>">
                                                    <i class="fa fa-image"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if($service->videos_exists): ?>
                                                <a class="btn btn-info" title="Videolar"
                                                    href="<?php echo e(route('admin.service.videos', $service->id)); ?>">
                                                    <i class="fa fa-video"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a class="btn btn-success" title="Düzəliş et"
                                                href="<?php echo e(route('admin.service.edit', $service->id)); ?>">
                                                <i class="fa fa-outdent"></i>
                                            </a>
                                            <a title="Sil" href="<?php echo e(route('admin.service.delete', $service->id)); ?>"
                                                class="btn btn-danger">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($services->links()); ?>

                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\bizim_production\resources\views/admin/services/list.blade.php ENDPATH**/ ?>