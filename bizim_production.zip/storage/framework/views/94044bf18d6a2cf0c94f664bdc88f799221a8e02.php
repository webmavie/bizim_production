<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('back/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('back/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('back/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- JQVMap -->
<script src="<?php echo e(asset('back/plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('back/plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('back/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('back/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('back/dist/js/adminlte.js')); ?>"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(asset('back/dist/js/pages/dashboard.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH /www/wwwroot/bizimproduction.az/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>