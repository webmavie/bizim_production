
<?php $__env->startSection('title', 'Modellər'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <h1 class="m-0">Modellər
                            <a href="<?php echo e(route('admin.model.create')); ?>" class="btn btn-success float-right">Yeni</a>
                        </h1>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 20px">#</th>
                                <th>Əsas Şəkil</th>
                                <th>Səhifə Şəkli</th>
                                <th>Ad</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="#" class="align-middle"><?php echo e($model->id); ?></td>
                                    <td data-label="Əsas Şəkil" style="width: 150px" class="align-middle">
                                        <a target="_blank" href="<?php echo e(asset($model->main_image)); ?>">
                                            <img class="table_img" style="width: 100%; height: auto"
                                                src="<?php echo e(asset($model->main_image)); ?>" alt="<?php echo e($model->name); ?>">
                                        </a>
                                    </td>
                                    <td data-label="Səhifə Şəkli" style="width: 150px" class="align-middle">
                                        <a target="_blank" href="<?php echo e(asset($model->image)); ?>">
                                            <img class="table_img" style="width: 100%; height: auto"
                                                src="<?php echo e(asset($model->image)); ?>" alt="<?php echo e($model->name); ?>">
                                        </a>
                                    </td>
                                    <td data-label="Ad" class="align-middle">
                                        <?php echo e($model->name); ?>

                                    </td>
                                    <td data-label="Prc" class="align-middle">
                                        <div class="prc"
                                            style="height: 100%; gap: 5px; display: grid; justify-content: center; align-services:center;">
                                            <a class="btn btn-primary" title="Şəkillər"
                                                href="<?php echo e(route('admin.model.images', $model->id)); ?>">
                                                <i class="fa fa-image"></i>
                                            </a>
                                            <a class="btn btn-success" title="Düzəliş et"
                                                href="<?php echo e(route('admin.model.edit', $model->id)); ?>">
                                                <i class="fa fa-outdent"></i>
                                            </a>
                                            <a title="Sil" href="<?php echo e(route('admin.model.delete', $model->id)); ?>"
                                                class="btn btn-danger">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($models->links()); ?>

                </div>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>
                            <?php echo implode('<br/>', $errors->all('<span>:message</span>')); ?>

                        </strong>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="card card-default">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.model_info.update')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <div class="row">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-12" data-select2-id="29">
                                    <div class="form-group">
                                        <label>Başlıq</label>
                                        <textarea id="summernote" class="form-control" name="model_title" cols="30"
                                            rows="5"><?php echo e($info->model_title); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-switch col-md-6">
                                            <input type="checkbox" <?php if($info->models == 1): ?> checked <?php endif; ?>
                                                name="models" class="custom-control-input" id="customSwitch1">
                                            <label class="custom-control-label" for="customSwitch1">Modelləri
                                                göstər</label>
                                        </div>
                                    </div>
                                    <div class="d-flex form-group col-md-12 justify-content-center">
                                        <div
                                            style="display: inline; padding: 5px; border-style: dashed; border-radius: 15px">
                                            <img style="object-fit: cover; border-radius: 10px"
                                                src="<?php echo e(asset($info->model_image)); ?>" class="img-fluid"
                                                alt="ModelImage" style="object-fit: cover" width="450px" height="auto"
                                                id="img">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 d-flex justify-content-center">
                                        <span class="btn btn-primary btn-file mx-auto">
                                            Şəkil seç<input id="ImgInp" type="file" name="model_image">
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success float-right">Saxla</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->startSection('js'); ?>
    <script>
        imgInp = document.getElementById('ImgInp');
        img = document.getElementById('img');
        imgInp.onchange = evt => {
            const [file] = imgInp.files
            if (file) {
                img.src = URL.createObjectURL(file);
            }
        }
        $(document).ready(function() {
            $('#summernote').summernote({
                height: 150,
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\bizim_production\resources\views/admin/models/list.blade.php ENDPATH**/ ?>