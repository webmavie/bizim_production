
<?php $__env->startSection('title', 'Komandamız'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <h1 class="m-0">Komandamız
                            <a href="<?php echo e(route('admin.our-team.create')); ?>" class="btn btn-success float-right">Yeni</a>
                        </h1>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <form action="<?php echo e(route('admin.our_team_title.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="input-group">
                                <label class="col-md-12" for="title">Başlıq</label>
                                <input type="text" name="our_team_title" value="<?php echo e($our_team_title); ?>"
                                    class="form-control" placeholder="Başlıqı dəyiş">
                                <button type="submit" class="input-group-text btn btn-success btn-sm">
                                    <i class="fas fa-check"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 20px">#</th>
                                <th>Şəkil</th>
                                <th>Ad</th>
                                <th>Vəzifə</th>
                                <th>Prc</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $our_team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="#" class="align-middle"><?php echo e($member->id); ?></td>
                                    <td data-label="Şəkil" style="width: 150px" class="align-middle">
                                        <img class="table_img" style="width: 100%; height: auto"
                                            src="<?php echo e(asset($member->image)); ?>" alt="<?php echo e($member->name); ?>">
                                    </td>
                                    <td data-label="Ad" class="align-middle"><?php echo e($member->name); ?></td>
                                    <td data-label="Vəzifə" class="align-middle"><?php echo e($member->position); ?></td>
                                    <td data-label="Prc" class="align-middle">
                                        <div class="prc"
                                            style="height: 100%; gap: 5px; display: flex; justify-content: center; align-members:center;">
                                            <a class="btn btn-success" title="Düzəliş et"
                                                href="<?php echo e(route('admin.our-team.edit', $member->id)); ?>">
                                                <i class="fa fa-outdent"></i>
                                            </a>
                                            <a title="Sil" href="<?php echo e(route('admin.our-team.delete', $member->id)); ?>"
                                                class="btn btn-danger">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($our_team->links()); ?>

                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\bizim_production\resources\views/admin/our-team/list.blade.php ENDPATH**/ ?>