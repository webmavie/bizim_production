
<?php $__env->startSection('title', 'Partnerlər'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Partnerlər</h1>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>
                            <?php echo implode('<br/>', $errors->all('<span>:message</span>')); ?>

                        </strong>
                    </div>
                <?php endif; ?>
                <div class="card card-default">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.partners.store')); ?>" method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row d-flex">
                                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-2" style="margin-bottom: 1rem;">
                                            <a href="<?php echo e($partner->logo); ?>" target="_blank">
                                                <div style="height: calc(100% - 15px); padding: 5px; border-style: dashed; border-radius: 5px">
                                                    <img style="margin-bottom: 1rem; object-fit: cover; border-radius: 5px"
                                                        src="<?php echo e(asset($partner->logo)); ?>" alt="Slide" width="100%" height="100%">
                                                        <a href="<?php echo e(route('admin.partner.delete', $partner->id)); ?>"
                                                            class="btn btn-danger btn-sm"
                                                            style="position: absolute; top: 0; right: 7px;"><i
                                                            class="fa fa-trash"></i></a>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="form-group col-md-12 d-flex justify-content-center">
                                    <span class="btn btn-primary btn-file mx-auto">
                                        Şəkillər yüklə<input id="file-input" type="file" name="images[]" multiple>
                                    </span>
                                </div>
                                <div class="form-group col-md-12 d-flex justify-content-center">
                                    <div class="col-md-12" id="preview"></div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success float-right">Saxla</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    <?php $__env->startSection('js'); ?>
        <script>
            function previewImages() {

                var preview = document.querySelector('#preview');

                if (this.files) {
                    [].forEach.call(this.files, readAndPreview);
                }

                function readAndPreview(file) {

                    // Make sure `file.name` matches our extensions criteria
                    if (!/\.(jpe?g|png|gif)$/i.test(file.name)) {
                        return alert(file.name + " is not an image");
                    } // else...

                    var reader = new FileReader();

                    reader.addEventListener("load", function() {
                        var image = new Image();
                        image.height = 100;
                        image.title = file.name;
                        image.src = this.result;
                        preview.appendChild(image);
                    });

                    reader.readAsDataURL(file);

                }

            }

            document.querySelector('#file-input').addEventListener("change", previewImages);
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\prj\bizim_production\resources\views/admin/partners.blade.php ENDPATH**/ ?>