<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('back/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('back/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('back/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('back/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('back/dist/js/adminlte.min.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH C:\Users\User\Desktop\bizim_production\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>