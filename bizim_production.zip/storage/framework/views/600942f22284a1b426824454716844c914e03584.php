
<?php $__env->startSection('title'); ?>
    <?php echo e($service->name); ?> - Videolar
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($service->name); ?> - Videolar</h1>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>
                            <?php echo implode('<br/>', $errors->all('<span>:message</span>')); ?>

                        </strong>
                    </div>
                <?php endif; ?>
                <div class="card card-default">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.service.video.store')); ?>" method="POST">
                            <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <style>
.video-container {
    position: relative;
    padding-bottom: 56.25%; /* 16:9 */
    height: 0;
}
.video-container iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
                                </style>
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6" style="margin-bottom: 1rem;">
                                            <div class="video-container">
                                            <iframe width="100%" height="100%" src="<?php echo e($video->link); ?>"
                                                title="video player" frameborder="0"
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                allowfullscreen></iframe>
                                            </div>
                                            <a href="<?php echo e(route('admin.service.video.delete', $video->id)); ?>"
                                                class="btn btn-danger btn-sm"
                                                style="position: absolute; top: 44%; right: 7px;"><i
                                                    class="fa fa-trash"></i></a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="input-group col-md-12">
                                    <input type="text" name="link" class="form-control" placeholder="Video linki">
                                    <button type="submit" class="btn btn-success float-right">Əlavə et</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/bizimproduction.az/resources/views/admin/services/videos.blade.php ENDPATH**/ ?>