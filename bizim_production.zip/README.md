aaPanel Internet Address: http://192.46.236.48:7800/d75f260e
aaPanel Internal Address: http://192.46.236.48:7800/d75f260e
username: 4yuzrufa
password: c275ac04

linode username: sharifovalyar
linode password: sharifovalyar.123

cloudflare email: sharifovalyar@gmail.com
cloudflare password: sharifovalyar.123

domain sayt.az:
    login: 994502522546
    password: 28vp9w
